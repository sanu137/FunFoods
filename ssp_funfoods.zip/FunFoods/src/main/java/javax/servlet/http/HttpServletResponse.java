package javax.servlet.http;

public class HttpServletResponse {

}
